window.onscroll = () => {
    document.querySelector('#toggle').checked = false;
}